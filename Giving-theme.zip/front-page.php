
<?php
get_template_part( 'template-parts/layout','home' )
?>
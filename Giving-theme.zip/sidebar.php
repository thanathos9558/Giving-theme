<div id="secondary" class="secondary ">
    <?php dynamic_sidebar( 'sidebar-2' ) ?>
</div>


